import numpy as np
import pylab as pl
from sklearn import svm
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix,classification_report
from sklearn.metrics import confusion_matrix
from time import time
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import itertools
import logging
import joblib
from sklearn.model_selection import train_test_split
from sklearn import datasets
from sklearn.model_selection import GridSearchCV

target_names=['Shooting','Passing','Lay-up','Others']
def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    #plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title,fontsize=20,fontweight='bold').set_position([.5, 1.05])
    plt.colorbar()
    tick_marks = np.arange(len(classes))

    plt.tick_params(labelsize=20)

    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 {"horizontalalignment":"center","fontsize":20,'verticalalignment': 'center'},
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()

    def_font = {'fontsize': 'large','verticalalignment': 'center','horizontalalignment': 'right','rotation' : 'vertical'}

    ylabel = plt.ylabel('True label')
    ylabel.set_fontsize(20)
    ylabel.set_fontname('Arial')
    xlabel= plt.xlabel('Predicted label')
    xlabel.set_fontsize(20)
    xlabel.set_fontsize(20)

#Train with all data
X=np.loadtxt('window_4_30_variables_raw.csv', delimiter=',', skiprows=1, usecols=(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29), unpack=False)
y=np.loadtxt('window_4_30_variables_raw.csv',delimiter=',',skiprows=1,usecols=(30,),unpack=False)

X_Train,X_Test, y_Train, y_Test= train_test_split(X,y,test_size=0.5,random_state=0)

#Compute a PCA(eigenfaces) on the dataset
n=8
print("Extracting the top %d components from %d datasets"%(n,X.shape[0]))
t0=time()
pca=PCA(n_components=n,svd_solver='randomized',whiten=True)
pca.fit(X_Train)
#PCA(copy=True, iterated_power='auto', n_components=n, random_state=None,svd_solver='auto', tol=0.0, whiten=False)
# print(pca.components_[n])
print("First Components is:")
print(pca.components_[0])
print("Second Components is:")
print(pca.components_[1])
print("Third Components is:")
print(pca.components_[2])
print("4th Components is:")
print(pca.components_[3])
print("5th Components is:")
print(pca.components_[4])
print("6th Components is:")
print(pca.components_[5])
print("7th Components is:")
print(pca.components_[6])
print("8th Components is:")
print(pca.components_[7])



print("explained_variance_ratio_:")
print(pca.explained_variance_ratio_)
print("explained_variance_:")
print(pca.explained_variance_)
print("n_components:")
print(pca.n_components)
print("noise_variance:")
print(pca.noise_variance_)


print("PCA Model done in%0.3fs"%(time()-t0))
t0=time()
X_Train_pca=pca.transform(X_Train)

print("X_Train_pca:")
print(X_Train_pca)
print("X_Train_pca shape:")
print(X_Train_pca.shape)
X_Test_pca=pca.transform(X_Test)
print("PCA Transform done in%0.3fs"%(time()-t0))


# Select Classifier
#Train a SVM Classification Model
print("Fitting the classifier to the training set:")
t0=time()
param_grid={'C':[1e3,5e3,1e4,5e4,1e5],'gamma':[0.0001,0.0005,0.001,0.005,0.01,0.1],}
clf=GridSearchCV(SVC(kernel='rbf',class_weight='balanced'),param_grid,cv=5)
clf.fit(X_Train_pca,y_Train)
print("Best estimator found by grid search:")
print(clf.best_estimator_)
print("Best estimator done in%0.3fs"%(time()-t0))
print()

t0=time()
print("Grid scores found by grid search:")
print(clf.cv_results_)
print("cv_results_ done in%0.3fs"%(time()-t0))
print()

y_Pred=clf.predict(X_Test_pca)
print("The predict y is:")
print(y_Pred)
print("Confusion matrix is:")
print(confusion_matrix(y_Test, y_Pred))
print("The classification report is:")
print(classification_report(y_Test,y_Pred,target_names=target_names))

cnf_matrix=confusion_matrix(y_Test, y_Pred)
# Plot non-normalized confusion matrix
plt.figure()
plot_confusion_matrix(cnf_matrix, classes=target_names,
                      title='Confusion Matrix of Actions Recognition')
plt.savefig('Confusion Matrix of Actions Recognition.png' )
plt.show()


#RBF核SVM 的需要调整正则超参数包括C（正则系数，一般在log域（取log后的值）均匀设置候选参数）和核函数的宽度gamma
#C越小，决策边界越平滑；
#gamma越小，决策边界越平滑。
from sklearn.svm import SVC
def fit_grid_point_RBF(C, gamma, X_Train_pca, y_Train, X_Test_pca, y_Test):
    
    # 在训练集是那个利用SVC训练
    SVC3 =  SVC( C = C, kernel='rbf', gamma = gamma)
    SVC3 = SVC3.fit(X_Train_pca, y_Train)
    
    # 在校验集上返回accuracy
    accuracy = SVC3.score(X_Test_pca, y_Test)
    
    print("accuracy: {}".format(accuracy))
    return accuracy

#需要调优的参数
C_s = np.logspace(-1, 2, 4)# logspace(a,b,N)把10的a次方到10的b次方区间分成N份 
gamma_s = np.logspace(-5, -2, 4)  
print(C_s)
print(gamma_s)
accuracy_s = []
for i, oneC in enumerate(C_s):
    for j, gamma in enumerate(gamma_s):
        #print("ssss")
        tmp = fit_grid_point_RBF(oneC, gamma, X_Train_pca, y_Train, X_Test_pca, y_Test)
        accuracy_s.append(tmp)

#gamma越大，对应RBF核的sigma越小，决策边界更复杂，可能发生了过拟合
 
accuracy_s1 =np.array(accuracy_s).reshape(len(C_s),len(gamma_s))
x_axis = np.log10(C_s)
for j, gamma in enumerate(gamma_s):
    plt.plot(x_axis, np.array(accuracy_s1[:,j]), label = ' Test - log(gamma)' + str(np.log10(gamma)))
 
plt.legend()
plt.xlabel( 'log(C)' )                                                                                                      
plt.ylabel( 'accuracy' )
plt.savefig('RBF_SVM_Otto.png' )
 
plt.show()
