
import numpy as np
import pylab as pl
# from sklearn import svm
from sklearn.svm import SVC
# from dask.array.learn import predict
from sklearn.metrics import confusion_matrix,classification_report
from sklearn.metrics import confusion_matrix
from time import time
import matplotlib.pyplot as plt
import itertools
import logging
import joblib
from sklearn.model_selection import train_test_split
from sklearn import datasets
from sklearn.model_selection import GridSearchCV



#SVM中 SVC (classification)

# 导入数据集拆分工具
from sklearn.model_selection import train_test_split
# 建立训练数据集和测试数据集
#Train with all data
X=np.loadtxt('window_4_30_variables_raw.csv', delimiter=',', skiprows=1, usecols=(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29), unpack=False)
y=np.loadtxt('window_4_30_variables_raw.csv',delimiter=',',skiprows=1,usecols=(30,),unpack=False)

X_Train,X_Test, y_Train, y_Test= train_test_split(X,y,test_size=0.5,random_state=0)

print(X_Train.shape)
print(X_Test.shape)

# 导入支持向量机回归模型
from sklearn.svm import SVC
# 分别测试sklearn核函数和rbf核函数
for kernel in ['rbf']:
    svc=SVC(kernel=kernel)
    svc.fit(X_Train,y_Train)
    print(kernel,'核函数的模型训练集(Train)得分：{:.3f}'.format(svc.score(X_Train,y_Train)))
    print(kernel,'核函数的模型测试集(Test)得分：{:.3f}'.format(svc.score(X_Test,y_Test)))
#可能原因：各个特征之间的量级差的比较远。SVM算法对于数据预处理的要求是比较高的，如果数据特征量差异较大，需要对数据进行预处理。
    

#画图查看数据集中各个特征的数量级，如下：

# 将特征数值中的最小值和最大值用散点图画出来
plt.plot(X.min(axis=0),'v',label='min')
plt.plot(X.max(axis=0),'^',label='max')

# 设定纵坐标为对数形式
plt.yscale('log')

# 设置图注位置为最佳
plt.legend(loc='best')

# 设定横纵轴标题
plt.xlabel('features')
plt.ylabel('feature magnitude')

# 显示图形
plt.show()

#结果解释：数据集的各个特征之间的量级差的比较远。处理方式：为了能够让SVM算法能够更好地对数据进行拟合，我们对数据集进行预处理，如下：

# 导入数据预处理工具
from sklearn.preprocessing import StandardScaler
# 对训练集和测试集进行数据预处理
scaler=StandardScaler()
scaler.fit(X_Train)
X_Train_scaled=scaler.transform(X_Train)
X_Test_scaled=scaler.transform(X_Test)

# 将预处理后的数据特征最大值和最小值用散点图表示出来
plt.plot(X_Train_scaled.min(axis=0),'v',label='Train set min')
plt.plot(X_Train_scaled.max(axis=0),'^',label='Train set max')
plt.plot(X_Test_scaled.min(axis=0),'v',label='Test set min')
plt.plot(X_Test_scaled.max(axis=0),'^',label='Test set max')
plt.yscale('log')

# 设置图注位置
plt.legend(loc='best')

# 设置横纵轴标题
plt.xlabel('scaled features')
plt.ylabel('scaled feature magnitude')

plt.show()

#结果分析：经过预处理，不管是训练集还是测试集，最大值就在0-10之间，最小值趋于0.

#用预处理好的数据，来训练模型，如下：

# 导入支持向量机回归模型
from sklearn.svm import SVC
# 分别测试sklearn核函数和rbf核函数
for kernel in ['rbf']:
    svc=SVC(kernel=kernel)
    svc.fit(X_Train_scaled,y_Train)
    print('预处理后，rbf内核的SVC得分:')
    print(kernel,'核函数的模型训练集(Train)得分：{:.3f}'.format(svc.score(X_Train_scaled,y_Train)))
    print(kernel,'核函数的模型测试集(Test)得分：{:.3f}'.format(svc.score(X_Test_scaled,y_Test)))
#结果分析：预处理后，rbf内核的SVC得分有了巨大的提升
    
#调节SVC模型也有gamma和C两个参数，如下：
    # 设置模型的C参数和gamma参数
svc=SVC(C=100,gamma=0.02)
svc.fit(X_Train_scaled,y_Train)
print('参数调节后：')
print('C=100,gamma=0.02')
print('调节参数后的模型在训练集得分：{:.3f}'.format(svc.score(X_Train_scaled,y_Train)))
print('调节参数后的模型在测试集得分：{:.3f}'.format(svc.score(X_Test_scaled,y_Test)))


#plots the confusion matrix
target_names=['Shooting','Passing',"Lay-up","Others"]
def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    #plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title,fontsize=20,fontweight='bold').set_position([.5, 1.05])
    plt.colorbar()
    tick_marks = np.arange(len(classes))

    plt.tick_params(labelsize=20)

    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 {"horizontalalignment":"center","fontsize":20,'verticalalignment': 'center'},
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()

    def_font = {'fontsize': 'large','verticalalignment': 'center','horizontalalignment': 'right','rotation' : 'vertical'}

    ylabel = plt.ylabel('True label')
    ylabel.set_fontsize(20)
    ylabel.set_fontname('Arial')
    xlabel= plt.xlabel('Predicted label')
    xlabel.set_fontsize(20)
    xlabel.set_fontsize(20)
    
# Select Classifier
#Train a SVM Classification Model
print("Fitting the classifier to the training set:")
t0=time()
param_grid={'C':[1e3,5e3,1e4,5e4,1e5],'gamma':[0.0001,0.0005,0.001,0.005,0.01,0.1],}
clf=GridSearchCV(SVC(kernel='rbf',class_weight='balanced'),param_grid,cv=5)
clf.fit(X_Train_scaled,y_Train)
print("Best estimator found by grid search:")
print(clf.best_estimator_)
print("Best estimator done in%0.3fs"%(time()-t0))
print()

t0=time()
print("Grid scores found by grid search:")
print(clf.cv_results_)
print("cv_results_ done in%0.3fs"%(time()-t0))
print()

y_Pred=clf.predict(X_Test_scaled)
print("The predict y is:")
print(y_Pred)
print("Confusion matrix is:")
print(confusion_matrix(y_Test, y_Pred))
print("The classification report is:")
print(classification_report(y_Test,y_Pred,target_names=target_names))

cnf_matrix=confusion_matrix(y_Test, y_Pred)
# Plot non-normalized confusion matrix
plt.figure()
plot_confusion_matrix(cnf_matrix, classes=target_names,
                      title='Confusion Matrix of Actions Recognition')
plt.savefig('Confusion Matrix of Actions Recognition.png' )
plt.show()


#参数调节 C&gamma


#需要调优的参数
from sklearn.svm import SVC
def fit_grid_point_RBF(C, gamma, X_Train_scaled, y_Train, X_Test_scaled, y_Test):
    
    # 在训练集是那个利用SVC训练
    SVC3 =  SVC( C = C, kernel='rbf', gamma = gamma)
    SVC3 = SVC3.fit(X_Train_scaled, y_Train)
    
    # 在校验集上返回accuracy
    accuracy = SVC3.score(X_Test_scaled, y_Test)
    
    print("accuracy: {}".format(accuracy))
    return accuracy

C_s = np.logspace(-1, 2, 4)# logspace(a,b,N)把10的a次方到10的b次方区间分成N份 
gamma_s = np.logspace(-5, -2, 4)  
print(C_s)
print(gamma_s)
accuracy_s = []
for i, oneC in enumerate(C_s):
    for j, gamma in enumerate(gamma_s):
        #print("ssss")
        tmp = fit_grid_point_RBF(oneC, gamma, X_Train_scaled, y_Train, X_Test_scaled, y_Test)
        accuracy_s.append(tmp)

#gamma越大，对应RBF核的sigma越小，决策边界更复杂，可能发生了过拟合
 

#可视化
accuracy_s1 =np.array(accuracy_s).reshape(len(C_s),len(gamma_s))
x_axis = np.log10(C_s)
for j, gamma in enumerate(gamma_s):
    plt.plot(x_axis, np.array(accuracy_s1[:,j]), label = ' Test - log(gamma)' + str(np.log10(gamma)))
 
plt.legend()
plt.xlabel( 'log(C)' )                                                                                                      
plt.ylabel( 'accuracy' )
plt.savefig('RBF_SVM_Otto.png' )
 
plt.show()

