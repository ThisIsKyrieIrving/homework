

import numpy as np
import pylab as pl
from sklearn import svm
from sklearn.svm import SVC
from sklearn import neighbors
from sklearn.metrics import confusion_matrix,classification_report
from sklearn.metrics import confusion_matrix
from time import time
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import itertools
import logging
import joblib
from sklearn.model_selection import train_test_split
from sklearn import datasets
from sklearn.model_selection import GridSearchCV
from sklearn.neural_network import MLPClassifier


# MLPClassifier: MLP(Multilayer Perceptron)多层感知机,即人工神经网络（ANN，Artificial Neural Network）
#除了输入输出层，MLP中间可以有多个隐层，最简单的MLP只含一个隐层，即三层的结构.

# 导入数据集拆分工具
#from sklearn.model_selection import train_test_split

# 建立训练数据集和测试数据集
#Train with all data
X=np.loadtxt('basketball_movement_30_variables.csv', delimiter=',', skiprows=1, usecols=(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29), unpack=False)
y=np.loadtxt('basketball_movement_30_variables.csv',delimiter=',',skiprows=1,usecols=(30,),unpack=False)

X_Train,X_Test, y_Train, y_Test= train_test_split(X,y,test_size=0.5,random_state=0)

print(X_Train.shape)
print(X_Test.shape)



#plots the confusion matrix
target_names=['Shooting','Passing','Lay-up']
def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    #plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title,fontsize=20,fontweight='bold').set_position([.5, 1.05])
    plt.colorbar()
    tick_marks = np.arange(len(classes))

    plt.tick_params(labelsize=20)

    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 {"horizontalalignment":"center","fontsize":20,'verticalalignment': 'center'},
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()

    def_font = {'fontsize': 'large','verticalalignment': 'center','horizontalalignment': 'right','rotation' : 'vertical'}

    ylabel = plt.ylabel('True label')
    ylabel.set_fontsize(20)
    ylabel.set_fontname('Arial')
    xlabel= plt.xlabel('Predicted label')
    xlabel.set_fontsize(20)
    xlabel.set_fontsize(20)
    
# Select Classifier
#Train MLP
print("Fitting the classifier to the training set:")
t0=time()

#参数调节
   #solver： {‘lbfgs’, ‘sgd’, ‘adam’}, 默认 ‘adam’，用来优化权重 
         #- lbfgs：quasi-Newton方法的优化器,对小数据集来说，lbfgs收敛更快效果也更好。 
         #- sgd：随机梯度下降 
         #- adam： Kingma, Diederik, and Jimmy Ba提出的机遇随机梯度的优化器 ,默认solver ‘adam’在相对较大的数据集上效果比较好（几千个样本或者更多），

  #alpha :float,可选的，默认0.0001,正则化项参数
  #hidden_layer_sizes :元祖格式，长度=n_layers-2, 默认(100，），第i个元素表示第i个隐藏层的神经元的个数,如(100,100)表示两层，每层100个神经元。

clf = MLPClassifier(solver='lbfgs', alpha=1e-5,hidden_layer_sizes=(20,20), random_state=0)
clf.fit(X_Train,y_Train)
#是一个机器学习中常用的方法，用于训练一个分类器或回归器。该方法会将输入数据集 X_train 和目标变量 y_train 作为参数传入分类器或回归器（clf），并使用这些数据来训练模型。
# 在训练过程中，分类器或回归器将根据输入数据调整其内部参数，以最小化预测结果与实际结果之间的误差。一旦训练完成，就可以使用该分类器或回归器对新数据进行预测。
#打印估计模型对测试集预测的准确率和一些手工输入的预测结果。
print('Layers(层数)：%s，number of outputs(输出单元数量)：%s' % (clf.n_layers_, clf.n_outputs_))
predictions = clf.predict(X_Test)
print('accuracy rate：%s' % clf.score(X_Test, y_Test))
for i, p in enumerate(predictions[:10]):
    print('true value(真实值)：%s， predicted value(预测值)：%s' % (y_Test[i], p))

print("n_layers is:")
print (clf.n_layers_)
print("n_iter is:")
print (clf.n_iter_)
print("loss is:")
print (clf.loss_)

#out_activation输出激活函数的名称。
print("out_activation:")
print (clf.out_activation_)
#Softmax函数，或称归一化指数函数[1]:198，是逻辑函数的一种推广。它能将一个含任意实数的K维向量  {\displaystyle \mathbf {z} } {\displaystyle \mathbf {z} } “压缩”到另一个K维实向量  {\displaystyle \sigma (\mathbf {z} )} {\displaystyle \sigma (\mathbf {z} )} 中，使得每一个元素的范围都在 {\displaystyle (0,1)} {\displaystyle (0,1)}之间，并且所有元素的和为1。

y_Pred=clf.predict(X_Test)
print("The predict y is:")
print(y_Pred)
print("Confusion matrix is:")
print(confusion_matrix(y_Test, y_Pred))
print("The classification report is:")
print(classification_report(y_Test,y_Pred,target_names=target_names))

cnf_matrix=confusion_matrix(y_Test, y_Pred)
# Plot non-normalized confusion matrix
plt.figure()
plot_confusion_matrix(cnf_matrix, classes=target_names,
                      title='Confusion Matrix of Actions Recognition')
plt.savefig('Confusion Matrix of Actions Recognition.png' )
plt.show()

