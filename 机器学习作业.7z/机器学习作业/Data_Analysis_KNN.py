

import numpy as np
import pylab as pl
from sklearn import svm
from sklearn.svm import SVC
from sklearn import neighbors
from sklearn.metrics import confusion_matrix,classification_report
from sklearn.metrics import confusion_matrix
from time import time
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import itertools
import logging
# from sklearn.externals import joblib
from sklearn.model_selection import train_test_split
from sklearn import datasets
from sklearn.model_selection import GridSearchCV



# scikit-learn 中KNN,k-NearestNeighbor


# 导入数据集拆分工具
from sklearn.model_selection import train_test_split
# 建立训练数据集和测试数据集
#Train with all data
X=np.loadtxt('basketball_movement_30_variables.csv', delimiter=',', skiprows=1, usecols=(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29), unpack=False)
y=np.loadtxt('basketball_movement_30_variables.csv',delimiter=',',skiprows=1,usecols=(30,),unpack=False)

X_Train,X_Test, y_Train, y_Test= train_test_split(X,y,test_size=0.5,random_state=0)

print(X_Train.shape)
print(X_Test.shape)



#plots the confusion matrix
target_names=['Shooting','Passing','Lay-up']
def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]   #归一化
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    #plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.imshow(cm, interpolation='nearest', cmap=cmap)#显示混淆矩阵，其中cm是需要显示的混淆矩阵，cmap是用于显示混淆矩阵的颜色映射。
    plt.title(title,fontsize=20,fontweight='bold').set_position([.5, 1.05])
    plt.colorbar()# 在图像右侧添加一个颜色条，表示颜色映射的比例尺。
    tick_marks = np.arange(len(classes))# 这段代码创建了一个numpy数组，该数组包含从0到类别列表长度减1的所有整数值，用于设置绘图的x和y轴刻度。

    # 例如，如果类别列表为['cat'，'dog'，'bird']，则np.arange(len(classes))将返回[0, 1, 2]，这些值可以在混淆矩阵的x和y轴上用作刻度。

    plt.tick_params(labelsize=20)

    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 {"horizontalalignment":"center","fontsize":20,'verticalalignment': 'center'},
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()

    def_font = {'fontsize': 'large','verticalalignment': 'center','horizontalalignment': 'right','rotation' : 'vertical'}

    ylabel = plt.ylabel('True label')
    ylabel.set_fontsize(20)
    ylabel.set_fontname('Arial')
    xlabel= plt.xlabel('Predicted label')
    xlabel.set_fontsize(20)
    xlabel.set_fontsize(20)
    
# Select Classifier
#Train knn
print("Fitting the classifier to the training set:")
t0=time()

#n_neighbors 就是 kNN 里的 k，就是在做分类时，我们选取问题点最近的多少个最近邻。
#K值的选择与样本分布有关，一般选择一个较小的K值，可以通过交叉验证来选择一个比较优的K值，默认值是5。
#如果数据是三维或者三维以下的，可以通过可视化观察来调参。
clf=neighbors.KNeighborsClassifier(n_neighbors=5)
clf.fit(X_Train,y_Train)

y_Pred=clf.predict(X_Test)
print("The predict y is:")
print(y_Pred)
print("Confusion matrix is:")
print(confusion_matrix(y_Test, y_Pred))
print("The classification report is:")
print(classification_report(y_Test,y_Pred,target_names=target_names))

cnf_matrix=confusion_matrix(y_Test, y_Pred)
# Plot non-normalized confusion matrix
plt.figure()
plot_confusion_matrix(cnf_matrix, classes=target_names,
                      title='Confusion Matrix of Actions Recognition')
plt.savefig('Confusion Matrix of Actions Recognition.png' )
plt.show()



